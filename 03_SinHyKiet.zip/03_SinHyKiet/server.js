// server.js
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const multer = require('multer');

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(__dirname, 'public')));

// MongoDB connection (đúng theo MongoDB Compass của bạn)
mongoose.connect('mongodb://localhost:27017/dsWhey', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => console.log('✅ MongoDB connected'))
  .catch(err => console.log('❌ MongoDB error:', err));

// Multer config for image upload
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'public/images'),
  filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname)
});
const upload = multer({ dest: 'public/images' });

// Mongoose schema và model
const productSchema = new mongoose.Schema({
  id: String,
  name: String,
  price: Number,
  brand: String,
  image: String,
  createdAt: { type: Date, default: Date.now }
});

// CHÚ Ý: chỉ định rõ collection là 'ThucPhamBoSung'
const Product = mongoose.model('Product', productSchema, 'ThucPhamBoSung');

// Tạo ID tự động: WHEY + 0001
async function generateProductId() {
  const all = await Product.find();
  const numbers = all
    .map(p => parseInt(p.id?.slice(4)))
    .filter(n => !isNaN(n));
  const maxNumber = numbers.length > 0 ? Math.max(...numbers) : 0;
  return 'WHEY' + String(maxNumber + 1).padStart(4, '0');
}

// API lấy danh sách sản phẩm (hiện theo thời gian thêm gần nhất -> cuối danh sách)
app.get('/api/products', async (req, res) => {
  const { name, brand, minPrice, maxPrice } = req.query;
  const query = {};

  if (name) query.name = { $regex: name, $options: 'i' };
  if (brand) query.brand = brand;
  if (minPrice || maxPrice) {
    query.price = {};
    if (minPrice) query.price.$gte = Number(minPrice);
    if (maxPrice) query.price.$lte = Number(maxPrice);
  }

  const products = await Product.find(query).sort({ createdAt: 1 });
  res.json(products);
});

// API tạo sản phẩm mới (upload ảnh)
app.post('/api/products', upload.single('image'), async (req, res) => {
  try {
    const newId = await generateProductId();
    const product = new Product({
      id: newId,
      name: req.body.name,
      price: req.body.price,
      brand: req.body.brand,
      image: req.file ? req.file.filename : 'default.jpg'
    });
    await product.save();
    res.status(201).json(product);
  } catch (error) {
    res.status(500).json({ error: 'Tạo sản phẩm thất bại!' });
  }
});

// API xoá sản phẩm
app.delete('/api/products/:id', async (req, res) => {
  try {
    await Product.findByIdAndDelete(req.params.id);
    res.json({ message: 'Đã xoá sản phẩm' });
  } catch (error) {
    res.status(500).json({ error: 'Xoá sản phẩm thất bại!' });
  }
});

// API cập nhật sản phẩm (gồm sửa cả ảnh nếu có)
app.put('/api/products/:id', upload.single('image'), async (req, res) => {
  try {
    const updateData = {
      name: req.body.name,
      price: req.body.price,
      brand: req.body.brand
    };

    if (req.file) {
      updateData.image = req.file.filename; // 👈 lấy tên ảnh mới
    }

    const updated = await Product.findByIdAndUpdate(
      req.params.id,
      updateData,
      { new: true }
    );

    res.json(updated);
  } catch (err) {
    res.status(500).json({ error: 'Update failed' });
  }
});

// Trang chủ giới thiệu về website
app.get('/home', (req, res) => {
  res.sendFile(path.join(__dirname, 'public/pages/home.html'));
});

// Route mặc định: trả về home.html
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public/pages/home.html'));
});

// Route dành cho index.html khi người dùng truy cập trang sản phẩm
app.get('/index', (req, res) => {
  res.sendFile(path.join(__dirname, 'public/pages/index.html'));
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
