document.addEventListener("DOMContentLoaded", () => {
    loadProducts();
});

function loadProducts() {
    fetch('/products')
        .then(res => res.json())
        .then(data => renderTable(data));
}

function renderTable(data) {
    const tableBody = document.getElementById("product-list");
    tableBody.innerHTML = "";
    data.forEach(product => {
        let row = `
            <tr>
                <td>${product.id}</td>
                <td>${product.name}</td>
                <td>${product.price.toLocaleString()} đ</td>
                <td>${product.brand}</td>
                <td><img src="/images/${product.image}" alt="${product.name}" width="60"></td>
                <td>
                    <button onclick=\"deleteProduct('${product.id}')\">Xoá</button>
                    <button onclick=\"updateProduct('${product.id}', '${product.name}', '${product.price}', '${product.brand}', '${product.image}')\">Sửa</button>
                </td>
            </tr>
        `;
        tableBody.innerHTML += row;
    });
}

document.getElementById("addForm").addEventListener("submit", function (e) {
    e.preventDefault();
    const name = document.getElementById("newName").value;
    const price = document.getElementById("newPrice").value;
    const brand = document.getElementById("newBrand").value;
    const imageFile = document.getElementById("newImage").files[0];

    const formData = new FormData();
    formData.append("name", name);
    formData.append("price", price);
    formData.append("brand", brand);
    formData.append("image", imageFile);

    fetch('/products', {
        method: 'POST',
        body: formData
    }).then(res => res.text()).then(msg => {
        alert(msg);
        this.reset();
        loadProducts();
    });
});

document.getElementById("filterForm").addEventListener("submit", function (e) {
    e.preventDefault();
    const name = document.getElementById("searchName").value;
    const brand = document.getElementById("searchBrand").value;
    const minPrice = document.getElementById("minPrice").value;
    const maxPrice = document.getElementById("maxPrice").value;
    const sort1 = document.getElementById("sort1").value;
    const sort2 = document.getElementById("sort2").value;

    fetch(`/search?name=${name}&brand=${brand}&minPrice=${minPrice}&maxPrice=${maxPrice}`)
        .then(res => res.json())
        .then(data => {
            if (sort1 || sort2) {
                data.sort((a, b) => {
                    if (sort1 && a[sort1] !== b[sort1]) {
                        return a[sort1] > b[sort1] ? 1 : -1;
                    }
                    if (sort2 && a[sort2] !== b[sort2]) {
                        return a[sort2] > b[sort2] ? 1 : -1;
                    }
                    return 0;
                });
            }
            renderTable(data);
        });
});

function deleteProduct(id) {
    fetch(`/products/${id}`, { method: 'DELETE' })
        .then(() => loadProducts());
}

function updateProduct(id, oldName, oldPrice, oldBrand, oldImage) {
    const name = prompt("Tên mới:", oldName);
    const price = prompt("Giá mới:", oldPrice);
    const brand = prompt("Hãng mới:", oldBrand);
    const image = prompt("Tên file ảnh mới:", oldImage);

    if (!name || !price || !brand || !image) return;

    fetch(`/products/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, price, brand, image })
    }).then(() => loadProducts());
}

document.getElementById('filterForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = e.target;
    const params = new URLSearchParams(new FormData(form)).toString();
    const res = await fetch(`/api/products?${params}`);
    const data = await res.json();
    renderProducts(data);
  });
  